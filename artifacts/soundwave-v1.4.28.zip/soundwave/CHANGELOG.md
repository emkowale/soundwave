v1.4.28 — 2025-11-03

- Maintenance release.

v1.4.27 — 2025-11-03

- Maintenance release.

v1.4.26 — 2025-11-03

- Maintenance release.

v1.4.25 — 2025-11-03

- Maintenance release.

v1.4.24 — 2025-11-03

- Maintenance release.

v1.4.23 — 2025-11-03

- chore: initial import

## v1.4.22 — 2025-10-18

- Maintenance release.## v1.4.22 — 2025-10-18

- Maintenance release.## v1.4.21 — 2025-10-18

- Maintenance release.## v1.4.21 — 2025-10-18

- Import working tree (643014a)
## v1.4.20 - Release

## [1.2.1] - 2025-09-27

Auto-push; Order Sync column; original-art + product_image_full; logging.

