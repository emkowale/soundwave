v1.4.31 — 2025-11-22

Changed files:
- artifacts/soundwave-v1.4.29.zip
- assets/admin.cssdead
- assets/admin.jsdead
- assets/js/sw-admin-sync.jsdead
- docs/hub-mu-plugin-hide-placeholder-sku.phpdead
- includes/admin.php
- includes/admin/ajax-test.php
- includes/admin/class-sw-admin-thumbs.phpdead
- includes/admin/class-sw-order-sync-ajax.phpdead
- includes/admin/class-sw-order-sync-column.phpdead
- includes/admin/class-sw-sync-status-ajax.phpdead
- includes/admin/class-sw-thumb-debug.phpdead
- includes/admin/debug_banner.phpdead
- includes/admin/enqueue.php
- includes/admin/item-ui.php
- includes/admin/menu.phpdead
- includes/admin/screen_sync.phpdead
- includes/admin/settings.php
- includes/admin/status_labels.phpdead
- includes/class-soundwave-analytics-guard.phpdead
- includes/receiver/honor_totals.phpdead
- includes/soundwave-admin.phpdead
- includes/soundwave-rest-import.phpdead
- includes/sync/admin-list-assets.php
- includes/sync/admin-list-helpers.php
- includes/sync/admin-list.php
- includes/sync/payload-items.php
- includes/sync/payload.php
- includes/sync/sender-build.php
- includes/sync/sender-request.php
- includes/sync/sender-validation.php
- includes/sync/sender.php
- includes/ui/debug_panel_inline.phpdead
- includes/utils-hub-status.php
- includes/utils-meta.php
- includes/utils-settings.php
- includes/utils.php
- package/soundwave/CHANGELOG.md
- package/soundwave/README.md
- package/soundwave/assets/admin.css
- package/soundwave/assets/admin.js
- package/soundwave/assets/js/sw-admin-sync.js
- package/soundwave/assets/settings.js
- package/soundwave/docs/hub-mu-plugin-hide-placeholder-sku.php
- package/soundwave/includes/admin.php
- package/soundwave/includes/admin/actions.php
- package/soundwave/includes/admin/class-sw-admin-thumbs.php
- package/soundwave/includes/admin/class-sw-order-sync-ajax.php
- package/soundwave/includes/admin/class-sw-order-sync-column.php
- package/soundwave/includes/admin/class-sw-sync-status-ajax.php
- package/soundwave/includes/admin/class-sw-thumb-debug.php
- package/soundwave/includes/admin/debug_banner.php
- package/soundwave/includes/admin/menu.php
- package/soundwave/includes/admin/screen_sync.php
- package/soundwave/includes/admin/status_labels.php
- package/soundwave/includes/bootstrap.php
- package/soundwave/includes/class-finalizer.php
- package/soundwave/includes/class-soundwave-analytics-guard.php
- package/soundwave/includes/finalizer-bootstrap.php
- package/soundwave/includes/receiver/honor_totals.php
- package/soundwave/includes/soundwave-admin.php
- package/soundwave/includes/soundwave-rest-import.php
- package/soundwave/includes/sync.php
- package/soundwave/includes/sync/admin-list.php
- package/soundwave/includes/sync/ajax-orders.php
- package/soundwave/includes/sync/ajax-settings.php
- package/soundwave/includes/sync/auto.php
- package/soundwave/includes/sync/compat-hooks.php
- package/soundwave/includes/sync/dispatcher.php
- package/soundwave/includes/sync/extract_art.php
- package/soundwave/includes/sync/helpers/product-image.php
- package/soundwave/includes/sync/http_send.php
- package/soundwave/includes/sync/line_builder_placeholder.php
- package/soundwave/includes/sync/payload.php
- package/soundwave/includes/sync/payload_compose.php
- package/soundwave/includes/sync/payload_enrich_lineitem.php
- package/soundwave/includes/sync/payload_helpers.php
- package/soundwave/includes/sync/payload_overrides_paid.php
- package/soundwave/includes/sync/settings.php
- package/soundwave/includes/ui/debug_panel_inline.php
- package/soundwave/includes/updater.php
- package/soundwave/includes/utils.php
- package/soundwave/includes/validator.php
- package/soundwave/release.sh
- package/soundwave/soundwave.php
- package/soundwave/tools-audit/sync-all-files.txt
- package/soundwave/tools-audit/sync-included-files.txt
- package/soundwave/tools-audit/sync-includes.txt
- package/soundwave/tools-audit/sync-never-included.txt
- package/soundwave/tools-audit/sync-symbol-refs.tsv
- package/soundwave/tools-audit/sync-symbols.tsv
- release.sh
- soundwave.php
- tools-audit/sync-all-files.txt
- tools-audit/sync-included-files.txt
- tools-audit/sync-includes.txt
- tools-audit/sync-never-included.txt
- tools-audit/sync-symbol-refs.tsv
- tools-audit/sync-symbols.tsv

v1.4.30 — 2025-11-20

Changed files:
- artifacts/soundwave-v1.4.29.zip
- includes/admin.php
- includes/class-finalizer.php
- includes/class-soundwave-analytics-guard.php
- includes/sync/payload_compose.php
- includes/validator.php
- package/soundwave/CHANGELOG.md
- package/soundwave/includes/soundwave-admin.php
- package/soundwave/release.sh
- package/soundwave/soundwave.php
- soundwave.php

v1.4.29 — 2025-11-03

Changed files:
- artifacts/soundwave-v1.4.28.zip
- includes/soundwave-admin.php
- includes/sync/payload_overrides_paid.php
- package/soundwave/CHANGELOG.md
- package/soundwave/README.md
- package/soundwave/assets/admin.css
- package/soundwave/assets/admin.js
- package/soundwave/assets/js/sw-admin-sync.js
- package/soundwave/assets/settings.js
- package/soundwave/docs/hub-mu-plugin-hide-placeholder-sku.php
- package/soundwave/includes/admin.php
- package/soundwave/includes/admin/actions.php
- package/soundwave/includes/admin/class-sw-admin-thumbs.php
- package/soundwave/includes/admin/class-sw-order-sync-ajax.php
- package/soundwave/includes/admin/class-sw-order-sync-column.php
- package/soundwave/includes/admin/class-sw-sync-status-ajax.php
- package/soundwave/includes/admin/class-sw-thumb-debug.php
- package/soundwave/includes/admin/debug_banner.php
- package/soundwave/includes/admin/menu.php
- package/soundwave/includes/admin/screen_sync.php
- package/soundwave/includes/admin/status_labels.php
- package/soundwave/includes/bootstrap.php
- package/soundwave/includes/class-finalizer.php
- package/soundwave/includes/class-soundwave-analytics-guard.php
- package/soundwave/includes/finalizer-bootstrap.php
- package/soundwave/includes/receiver/honor_totals.php
- package/soundwave/includes/soundwave-admin.php
- package/soundwave/includes/soundwave-rest-import.php
- package/soundwave/includes/sync.php
- package/soundwave/includes/sync/admin-list.php
- package/soundwave/includes/sync/ajax-orders.php
- package/soundwave/includes/sync/ajax-settings.php
- package/soundwave/includes/sync/auto.php
- package/soundwave/includes/sync/compat-hooks.php
- package/soundwave/includes/sync/dispatcher.php
- package/soundwave/includes/sync/extract_art.php
- package/soundwave/includes/sync/helpers/product-image.php
- package/soundwave/includes/sync/http_send.php
- package/soundwave/includes/sync/line_builder_placeholder.php
- package/soundwave/includes/sync/payload.php
- package/soundwave/includes/sync/payload_compose.php
- package/soundwave/includes/sync/payload_enrich_lineitem.php
- package/soundwave/includes/sync/payload_helpers.php
- package/soundwave/includes/sync/payload_overrides_paid.php
- package/soundwave/includes/sync/sender.php
- package/soundwave/includes/sync/settings.php
- package/soundwave/includes/ui/debug_panel_inline.php
- package/soundwave/includes/updater.php
- package/soundwave/includes/utils.php
- package/soundwave/includes/validator.php
- package/soundwave/release.sh
- package/soundwave/soundwave.php
- package/soundwave/tools-audit/sync-all-files.txt
- package/soundwave/tools-audit/sync-included-files.txt
- package/soundwave/tools-audit/sync-includes.txt
- package/soundwave/tools-audit/sync-never-included.txt
- package/soundwave/tools-audit/sync-symbol-refs.tsv
- package/soundwave/tools-audit/sync-symbols.tsv
- release.sh
- soundwave.php

v1.4.28 — 2025-11-03

- Maintenance release.

v1.4.27 — 2025-11-03

- Maintenance release.

v1.4.26 — 2025-11-03

- Maintenance release.

v1.4.25 — 2025-11-03

- Maintenance release.

v1.4.24 — 2025-11-03

- Maintenance release.

v1.4.23 — 2025-11-03

- chore: initial import

## v1.4.22 — 2025-10-18

- Maintenance release.## v1.4.22 — 2025-10-18

- Maintenance release.## v1.4.21 — 2025-10-18

- Maintenance release.## v1.4.21 — 2025-10-18

- Import working tree (643014a)
## v1.4.20 - Release

## [1.2.1] - 2025-09-27

Auto-push; Order Sync column; original-art + product_image_full; logging.

